# Disparador WhatsApp no celular — Azul Empréstimo Noroeste

Painel feito para o celular, com senha, que você instala na tela inicial como um app. Usa a **API oficial da Meta**. Para funcionar 24h e guardar a lista, ele precisa ficar hospedado num servidor. O passo a passo abaixo usa o Render (plano pago básico, porque os gratuitos dormem e perdem os dados; confira o preço atual no site deles).

## Parte 1 — Conta na Meta (uma vez)
1. Crie e verifique a conta em business.facebook.com.
2. Em developers.facebook.com, crie um app "Business" e adicione o produto **WhatsApp**.
3. Cadastre o número da empresa (não pode estar no app WhatsApp comum).
4. Crie um **Usuário do sistema** e gere um **token permanente**. Anote também o **ID do número de telefone**.
5. Crie um modelo de mensagem (idioma pt_BR, com uma variável `{{1}}` para o nome), por exemplo:
   > Olá {{1}}, aqui é da Azul Empréstimo Noroeste. Posso te enviar uma simulação sem compromisso? Responda PARAR para não receber mais mensagens.

   Espere a aprovação e anote o **nome do modelo**.

## Parte 2 — Colocar no ar (uma vez, uns 10 minutos, mais fácil no computador)
1. Crie uma conta grátis em github.com e um repositório **privado** (ex.: `disparador`).
2. Envie para ele todos os arquivos desta pasta (`app.py`, `requirements.txt`, `render.yaml`, `Dockerfile`, `.gitignore` e a pasta `static`), pelo botão "Add file > Upload files".
3. Crie conta em render.com, toque em **New > Blueprint** e escolha o repositório. Ele lê o `render.yaml` e cria o serviço com um disco de 1 GB para guardar os dados.
4. Preencha as variáveis que ele pedir:
   - `APP_SENHA`: senha do painel (mínimo 8 caracteres, use uma forte)
   - `WA_TOKEN`: o token permanente da Meta
   - `WA_PHONE_ID`: o ID do número
   - `WA_TEMPLATE`: o nome do modelo aprovado
   - `WA_VERIFY_TOKEN`: uma senha inventada por você, para o webhook
5. Aguarde o deploy. O Render mostra o endereço, algo como `https://disparador-whatsapp.onrender.com`.

## Parte 3 — Instalar no celular
- **iPhone (Safari):** abra o endereço, toque em Compartilhar e em **Adicionar à Tela de Início**.
- **Android (Chrome):** abra o endereço, toque nos três pontos e em **Instalar app** (ou Adicionar à tela inicial).

Entre com a senha `APP_SENHA`. O login fica salvo por 30 dias.

## Parte 4 — Ligar o "PARAR"
No painel da Meta (WhatsApp > Configuração > Webhook):
- URL de retorno: `https://seu-endereco/webhook`
- Token de verificação: o mesmo valor de `WA_VERIFY_TOKEN`
- Assine o campo **messages**.

Quem responder PARAR sai da fila e nunca mais recebe.

## Usando no dia a dia
1. Abra o app e olhe **Configuração**: os quatro itens devem estar com ✓.
2. Use **Enviar teste** com o seu próprio número para conferir o modelo.
3. Em **Importar contatos**, cole ou escolha o CSV (`nome;telefone;autorizado`). Só entram os marcados `sim`.
4. Toque em **Iniciar envio**. Você acompanha o progresso e pode **Pausar** quando quiser.
5. Se a Meta sinalizar limite ou spam, ou houver 5 falhas seguidas, o envio para sozinho.

## Como o número fica protegido
- Só envia para quem autorizou, nunca repete envio, respeita quem pediu para sair.
- Pausa aleatória entre mensagens e limite por dia (`LIMITE_DIA`, padrão 100). Comece com 10 a 20 por dia e vá subindo.
- Muitos bloqueios e denúncias fazem a Meta reduzir o seu limite; mande só coisa útil para quem quer receber.
- O token dá acesso ao WhatsApp da empresa: nunca o mande a ninguém. Ele fica só no Render.

## Testar no computador antes (opcional)
```
pip install -r requirements.txt
APP_SENHA=umasenhaforte COOKIE_SEGURO=0 python app.py
```
Abra http://localhost:8000.
